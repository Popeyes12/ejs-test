var express = require('express');
var mysql = require('mysql');
app.set("view engine", "ejs");
var app = express();
var bodyparser = require("body-parser");
app.use(bodyparser.urlencoded({ extended: true }));

var con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'homework 3'
});

// Connection 
con.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the database');
});

// Main
app.get("/main", function (req, res) {
  res.render("main", { name: req.body.std_name, id: req.body.std_id });
});

// Display
app.get("/display", function (req, res) {


  var q1 = "select * from department;";
  con.query(q1, function (error, departmentResult) {
    if (error) throw error;

    var q2 = "select * from student;";
    con.query(q2, function (error, studentResult) {
      if (error) throw error;

      var q3 = "select * from instructor;";
      con.query(q3, function (error, instructorResult) {
        if (error) throw error;

        var q4 = "select * from advisor;";
        con.query(q4, function (error, advisorResult) {
          if (error) throw error;
          res.render("display", { studentData: studentResult, departmentData: departmentResult, advisorData: advisorResult, instructorData: instructorResult });

        });
      });
    });
  });
});


// Inset function

app.get("/insert", function (req, res) {
  res.render("insert");
});

app.get("/insert_advisor", function (req, res) {
  res.render("insert_advisor");
});

app.get("/insert_department", function (req, res) {
  res.render("insert_department");
});

app.get("/insert_student", function (req, res) {
  res.render("insert_student");
});

app.get("/insert_instructor", function (req, res) {
  res.render("insert_instructor");
});

app.post("/insert_adv", function (req, res) {

  const min = 100000;
  const max = 999999;

  if (req.body.std_SID == "") req.body.std_SID = (Math.floor(Math.random() * (max - min + 1)) + min).toString;
  if (req.body.std_IID == "") req.body.std_IID = (Math.floor(Math.random() * (max - min + 1)) + min).toString;

  var info = { S_ID: req.body.std_SID, I_ID: req.body.std_IID };
  var q = "INSERT INTO advisor SET ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error);

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/insert_ins", function (req, res) {

  const min = 100000;
  const max = 999999;

  if (req.body.std_ID == "") req.body.std_ID = (Math.floor(Math.random() * (max - min + 1)) + min).toString;
  if (req.body.std_building == "") req.body.std_building = "none";
  if (req.body.std_dept == "") req.body.std_dept = "none";
  if (req.body.std_salary == "") req.body.std_salary = "0";

  var info = { ID: req.body.std_ID, name: req.body.std_name, dept_name: req.body.std_dept, salary: req.body.std_salary };
  var q = "INSERT INTO instructor SET ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/insert_dept", function (req, res) {

  if (req.body.std_budget == "") req.body.std_budget = "0";
  if (req.body.std_building == "") req.body.std_building = "none";
  if (req.body.std_dept == "") req.body.std_dept = "none";

  var info = { dept_name: req.body.std_dept, building: req.body.std_building, budget: req.body.std_budget };
  var q = "INSERT INTO department SET ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/insert_stud", function (req, res) {

  const min = 100000;
  const max = 999999;

  if (req.body.std_ID == "") req.body.std_ID = (Math.floor(Math.random() * (max - min + 1)) + min).toString;
  if (req.body.std_building == "") req.body.std_building = "none";
  if (req.body.std_dept == "") req.body.std_dept = "none";
  if (req.body.std_credits == "") req.body.std_credits = "0";

  var info = { ID: req.body.std_ID, name: req.body.std_name, dept_name: req.body.std_dept, tot_credit: req.body.std_credits };
  var q = "INSERT INTO student SET ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});


// Search funcgtions

app.get("/search", function (req, res) {
  res.render("search");
});

app.get("/search_department", function (req, res) {
  res.render("search_department");
});

app.get("/search_student", function (req, res) {
  res.render("search_student");
});

app.get("/search_instructor", function (req, res) {
  res.render("search_instructor");
});

app.get("/search_advisor", function (req, res) {
  res.render("search_advisor");
});

app.get("/search_success_advisor", function (req, res) {
  res.render("search_success_advisor");
});

app.get("/search_success_student", function (req, res) {
  res.render("search_success_student");
});

app.get("/search_success_instructor", function (req, res) {
  res.render("search_success_instructor");
});

app.get("/search_success_department", function (req, res) {
  res.render("search_success_department");
});

app.get("/search_failure", function (req, res) {
  res.render("search_failure");
});

app.post("/search_adv", function (req, res) {
  var S_ID = req.body.std_SID;
  var I_ID = req.body.std_IID;
  var params = [S_ID, I_ID];

  var q = "SELECT * FROM advisor WHERE S_ID = ? AND I_ID = ?";

  if (S_ID == "" && I_ID == "") {
    q = "SELECT * FROM advisor";
  }

  else if (I_ID == "") {
    q = "SELECT * FROM advisor WHERE S_ID = ?";
    params = S_ID;
  }

  else if (S_ID == "") {
    q = "SELECT * FROM advisor WHERE I_ID = ?";
    params = I_ID;
  }


  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.length > 0) {

      res.render("search_success_advisor", { advisorData: results });
    } else {

      res.redirect("/search_failure");
    }
  });
});

app.post("/search_dept", function (req, res) {
  var dept_name = req.body.std_dept;
  var building = req.body.std_building;
  var budget = req.body.std_budget;
  var params = [dept_name, building, budget];

  var q = "SELECT * FROM department WHERE dept_name = ? AND building = ? AND budget = ?";

  if (dept_name == "" && building == "" && budget == "") {
    q = "SELECT * FROM department";
  }

  else if (dept_name == "" && building == "") {
    q = "SELECT * FROM department WHERE budget = ?";
    params = budget;
  }

  else if (dept_name == "" && budget == "") {
    q = "SELECT * FROM department WHERE building = ?";
    params = building;
  }

  else if (building == "" && budget == "") {
    q = "SELECT * FROM department WHERE dept_name = ?";
    params = dept_name;
  }

  else if (dept_name == "") {
    q = "SELECT * FROM department WHERE building = ? AND budget = ?";
    params = [building, budget];
  }

  else if (building == "") {
    q = "SELECT * FROM department WHERE dept_name = ? AND budget = ?";
    params = [dept_name, budget];
  }

  else if (budget == "") {
    q = "SELECT * FROM department WHERE dept_name = ? AND building = ?";
    params = [dept_name, building];
  }

  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.length > 0) {

      res.render("search_success_department", { departmentData: results });
    } else {

      res.redirect("/search_failure");
    }
  });
});

app.post("/search_ins", function (req, res) {
  var ID = req.body.std_ID;
  var name = req.body.std_name;
  var dept_name = req.body.std_dept;
  var salary = req.body.std_salary;
  var params = [ID, name, dept_name, salary];

  var q = "SELECT * FROM instructor WHERE ID = ? AND name = ? AND dept_name = ? AND salary = ?";

  if (ID == "" && name == "" & dept_name == "" && salary == "") {
    q = "SELECT * FROM instructor";
  }

  else if (ID == "" && name == "" & dept_name == "") {
    q = "SELECT * FROM instructor WHERE salary = ?";
    params = salary;
  }

  else if (ID == "" && name == "" & salary == "") {
    q = "SELECT * FROM instructor WHERE dept_name = ?";
    params = dept_name;
  }

  else if (ID == "" && dept_name == "" & salary == "") {
    q = "SELECT * FROM instructor WHERE name = ?";
    params = name;
  }

  else if (name == "" && dept_name == "" & salary == "") {
    q = "SELECT * FROM instructor WHERE ID = ?";
    params = ID;
  }

  else if (ID == "" && dept_name == "") {
    q = "SELECT * FROM instructor WHERE name = ? AND salary = ";
    params = [name, salary];
  }

  else if (ID == "" && name == "") {
    q = "SELECT * FROM instructor WHERE dept_name = ? AND salary = ";
    params = [dept_name, salary];
  }

  else if (ID == "" && salary == "") {
    q = "SELECT * FROM instructor WHERE dept_name = ? AND name = ";
    params = [dept_name, name];
  }

  else if (name == "" && dept_name == "") {
    q = "SELECT * FROM instructor WHERE ID = ? AND salary = ";
    params = [ID, salary];
  }

  else if (name == "" && salary == "") {
    q = "SELECT * FROM instructor WHERE ID = ? AND dept_name = ";
    params = [ID, dept_name];
  }

  else if (dept_name == "" && salary == "") {
    q = "SELECT * FROM instructor WHERE dept_name = ? AND salary = ";
    params = [dept_name, salary];
  }

  else if (ID == "") {
    q = "SELECT * FROM instructor WHERE name = ? AND dept_name = ? AND salary = ";
    params = [name, dept_name, salary];
  }

  else if (name == "") {
    q = "SELECT * FROM instructor WHERE ID = ? AND dept_name = ? AND salary = ?";
    params = [ID, dept_name, salary];
  }

  else if (dept_name == "") {
    q = "SELECT * FROM instructor WHERE ID = ? AND name = ? AND salary = ?";
    params = [ID, name, salary];
  }

  else if (salary == "") {
    q = "SELECT * FROM instructor WHERE ID = ? AND dept_name = ? AND name = ?";
    params = [ID, dept_name, name];
  }


  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.length > 0) {

      res.render("search_success_instructor", { instructorData: results });
    } else {

      res.redirect("/search_failure");
    }
  });
});

app.post("/search_stud", function (req, res) {
  var ID = req.body.std_ID;
  var name = req.body.std_name;
  var dept_name = req.body.std_dept;
  var tot_credit = req.body.std_credits;
  var params = [ID, name, dept_name, tot_credit];

  var q = "SELECT * FROM student WHERE ID = ? AND name = ? AND dept_name = ? AND tot_credit = ?";

  if (ID == "" && name == "" & dept_name == "" && tot_credit == "") {
    q = "SELECT * FROM student";
  }

  else if (ID == "" && name == "" & dept_name == "") {
    q = "SELECT * FROM student WHERE tot_credit = ?";
    params = tot_credit;
  }

  else if (ID == "" && name == "" & tot_credit == "") {
    q = "SELECT * FROM student WHERE dept_name = ?";
    params = dept_name;
  }

  else if (ID == "" && dept_name == "" & tot_credit == "") {
    q = "SELECT * FROM student WHERE name = ?";
    params = name;
  }

  else if (name == "" && dept_name == "" & tot_credit == "") {
    q = "SELECT * FROM student WHERE ID = ?";
    params = ID;
  }

  else if (ID == "" && dept_name == "") {
    q = "SELECT * FROM student WHERE name = ? AND tot_credit = ";
    params = [name, tot_credit];
  }

  else if (ID == "" && name == "") {
    q = "SELECT * FROM student WHERE dept_name = ? AND tot_credit = ";
    params = [dept_name, tot_credit];
  }

  else if (ID == "" && tot_credit == "") {
    q = "SELECT * FROM student WHERE dept_name = ? AND name = ";
    params = [dept_name, name];
  }

  else if (name == "" && dept_name == "") {
    q = "SELECT * FROM student WHERE ID = ? AND tot_credit = ";
    params = [ID, tot_credit];
  }

  else if (name == "" && tot_credit == "") {
    q = "SELECT * FROM student WHERE ID = ? AND dept_name = ";
    params = [ID, dept_name];
  }

  else if (dept_name == "" && tot_credit == "") {
    q = "SELECT * FROM student WHERE dept_name = ? AND tot_credit = ";
    params = [dept_name, tot_credit];
  }

  else if (ID == "") {
    q = "SELECT * FROM student WHERE name = ? AND dept_name = ? AND tot_credit = ";
    params = [name, dept_name, tot_credit];
  }

  else if (name == "") {
    q = "SELECT * FROM student WHERE ID = ? AND dept_name = ? AND tot_credit = ?";
    params = [ID, dept_name, tot_credit];
  }

  else if (dept_name == "") {
    q = "SELECT * FROM student WHERE ID = ? AND name = ? AND tot_credit = ?";
    params = [ID, name, tot_credit];
  }

  else if (tot_credit == "") {
    q = "SELECT * FROM student WHERE ID = ? AND dept_name = ? AND name = ?";
    params = [ID, dept_name, name];
  }


  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.length > 0) {

      res.render("search_success_student", { studentData: results });
    } else {

      res.redirect("/search_failure");
    }
  });
});

// Delete Functions

app.get("/delete_department_name", function (req, res) {
  res.render("delete_department_name");
});

app.get("/delete_department_building", function (req, res) {
  res.render("delete_department_building");
});

app.get("/delete_department_budget", function (req, res) {
  res.render("delete_department_budget");
});
app.get("/delete", function (req, res) {
  res.render("delete");
});

app.get("/delete_department", function (req, res) {
  res.render("delete_department");
});



app.post("/delete_dept_name", function (req, res) {

  var info = { dept_name: req.body.std_dept_name };
  var q = "DELETE FROM department WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_dept_budget", function (req, res) {

  var info = { budget: req.body.std_budget };
  var q = "DELETE FROM department WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_dept_building", function (req, res) {

  var info = { building: req.body.std_building };
  var q = "DELETE FROM department WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.get("/delete_instructor_name", function (req, res) {
  res.render("delete_instructor_name");
});

app.get("/delete_instructor_dept", function (req, res) {
  res.render("delete_instructor_dept");
});

app.get("/delete_instructor_salary", function (req, res) {
  res.render("delete_instructor_salary");
});

app.get("/delete_instructor", function (req, res) {
  res.render("delete_instructor");
});

app.get("/delete_instructor_ID", function (req, res) {
  res.render("delete_instructor_ID");
});


app.post("/delete_inst_ID", function (req, res) {

  var info = { ID: req.body.std_ID };
  var q = "DELETE FROM instructor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_inst_name", function (req, res) {

  var info = { name: req.body.std_name };
  var q = "DELETE FROM instructor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_inst_dept", function (req, res) {

  var info = { dept_name: req.body.std_dept_name };
  var q = "DELETE FROM instructor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_inst_salary", function (req, res) {

  var info = { salary: req.body.std_salary };
  var q = "DELETE FROM instructor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.get("/delete_student_ID", function (req, res) {
  res.render("delete_student_ID");
});

app.get("/delete_student_name", function (req, res) {
  res.render("delete_student_name");
});

app.get("/delete_student_dept", function (req, res) {
  res.render("delete_student_dept");
});

app.get("/delete_student_credits", function (req, res) {
  res.render("delete_student_credits");
});

app.get("/delete_student", function (req, res) {
  res.render("delete_student");
});

app.post("/delete_stud_ID", function (req, res) {

  var info = { ID: req.body.std_ID };
  var q = "DELETE FROM student WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_stud_name", function (req, res) {

  var info = { name: req.body.std_name };
  var q = "DELETE FROM student WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_stud_dept", function (req, res) {

  var info = { dept_name: req.body.std_dept };
  var q = "DELETE FROM student WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_stud_credits", function (req, res) {

  var info = { tot_credit: req.body.std_credits };
  var q = "DELETE FROM student WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.get("/delete_advisor", function (req, res) {
  res.render("delete_advisor");
});

app.get("/delete_advisor_IID", function (req, res) {
  res.render("delete_advisor_IID");
});

app.get("/delete_advisor_SID", function (req, res) {
  res.render("delete_advisor_SID");
});

app.post("/delete_SID", function (req, res) {

  var info = { S_ID: req.body.std_SID };
  var q = "DELETE FROM advisor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/delete_IID", function (req, res) {

  var info = { I_ID: req.body.std_IID };
  var q = "DELETE FROM advisor WHERE ?";
  var success = true;

  con.query(q, info, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});



// Update Funcions
app.get("/update", function (req, res) {
  res.render("update");
});

app.get("/update_department", function (req, res) {
  res.render("update_department");
});

app.get("/update_student", function (req, res) {
  res.render("update_student");
});

app.get("/update_instructor", function (req, res) {
  res.render("update_instructor");
});

app.get("/update_advisor", function (req, res) {
  res.render("update_advisor");
});

app.post("/update_adv", function (req, res) {

  var params = [req.body.std_newSID, req.body.std_newIID, req.body.std_oldSID, req.body.std_oldIID];

  var q = "UPDATE advisor SET S_ID = ?, I_ID = ? WHERE (S_ID = ? AND I_ID = ?)";
  var success = true;

  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/update_dept", function (req, res) {

  var params = [req.body.std_newdept, req.body.std_newbuilding, req.body.std_newbudget, req.body.std_olddept, req.body.std_oldbuilding, req.body.std_oldbudget];

  var q = "UPDATE department SET dept_name = ?, building = ?, budget = ? WHERE (dept_name = ? AND building = ? AND budget = ?)";
  var success = true;

  con.query(q, params, function (error, results) {
    if (error) throw err;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/update_ins", function (req, res) {

  var params = [req.body.std_newID, req.body.std_newname, req.body.std_newdept, req.body.std_newsalary, req.body.std_oldID, req.body.std_oldname, req.body.std_olddept, req.body.std_oldsalary];

  var q = "UPDATE instructor SET ID = ?, name = ?, dept_name = ?, salary = ? WHERE (ID = ? AND name = ? AND dept_name = ? AND salary = ?)";
  var success = true;

  con.query(q, params, function (error, results) {
    if (error) throw error;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.post("/update_stud", function (req, res) {

  var params = [req.body.std_newID, req.body.std_newname, req.body.std_newdept, req.body.std_newcredit, req.body.std_oldID, req.body.std_oldname, req.body.std_olddept, req.body.std_oldcredit];

  var q = "UPDATE student SET ID = ?, name = ?, dept_name = ?, tot_credit = ? WHERE (ID = ? AND name = ? AND dept_name = ? AND tot_credit = ?)";
  var success = true;

  console.log(params);

  con.query(q, params, function (error, results) {
    if (error) throw error;

    if (results.affectedRows == 0) success = false;

    console.log(results);

    if (success) res.redirect("/query_success");
    else res.redirect("/query_failure");
  });
});

app.get("/query_success", function (req, res) {
  res.render("query_success");
});

app.get("/query_failure", function (req, res) {
  res.render("query_failure");
});


app.listen(3000, function () {
  console.log('App listening on port 3000!');
});
